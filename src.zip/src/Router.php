<?php

require_once ('Controllers/IndexController.php');
require_once ('Controllers/LoginController.php');
require_once ('Controllers/RegisterController.php');
require_once ('Controllers/LogoutController.php');
require_once ('Controllers/FilmAddController.php');
require_once ('Controllers/FilmController.php');
require_once ('Controllers/FilmDeleteController.php');
require_once ('Controllers/SearchByActorController.php');
require_once ('Controllers/SearchByNameController.php');
require_once ('Controllers/FileUploadController.php');

class Router {

    private string $method;
    private string $url;
    private array $data = [];

    /**
     * @var Request $request
     */
    public function __construct(Request $request)
    {
        $this->method=$request->getMethod();
        $this->url=$request->getUrl();
        $this->data=$request->getData();

        $this->getController($request);
    }
    /**
     * @var Request $request
     */
    protected function getController(Request $request):BaseController{
        $className = match ($request->getUrl()){
            '/' => IndexController::class,
            '/login' => LoginController::class,
            '/register' => RegisterController::class,
            '/logout'   => LogoutController::class,
            '/addfilm' => FilmAddController::class,
            '/film'=> FilmController::class,
            '/filmdelete' => FilmDeleteController::class,
            '/searchbyactor' => SearchByActorController::class,
            '/searchbyname' => SearchByNameController::class,
            '/upload' =>  FileUploadController::class
        };

        return new $className($request);
    }
}
