<?php
return [
    'host' => 'mysql',
    'user' => 'root',
    'password' => 'rootpass',
    'db_name' => 'films_test_task'
];