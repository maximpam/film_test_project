<?php
require_once ('BaseController.php');

class FileUploadController extends BaseController
{
    /**
     * @var Request $request
     */
    public function __construct(Request $request)
    {
        match ($request->getMethod()){
            'GET'=> $this->index($request),
            'POST'=>$this->upload($request)
        };

    }
    /**
     * @var Request $request
     */
    private function index(Request $request)
    {
        if ($request->isLogin() === true){
            require_once ('views/upload.phtml');
        } else {
            header('Location: /');
        }

    }

}