<?php

require_once ('BaseController.php');
require_once ('FilmController.php');

class IndexController extends BaseController
{
    /**
     * @var Request $request
     */
    public function __construct(Request $request)
    {
         match ($request->getMethod()){
            'GET'=> $this->index($request)
        };


    }

    private function index($request){

        if ($request->isLogin() === true){
            $films = FilmController::getFilms($request);
            require_once ('views/index.phtml');
        } else{
            header('Location: /login');
        }
    }
}