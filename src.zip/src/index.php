<?php
session_start();
require 'App.php';

$app = new App();
$app->run();

//var_dump($_SERVER);